import { Outlet } from "react-router-dom";
// ... sidebar + floating panel logic ...

<main className="app-content">
  <Outlet />
</main>;

import React from "react";
import "../styles/components.css";
import "../styles/formtoolbar.css";

type ViewMode = "zoomed" | "mid" | "full";

interface FormToolbarProps {
  view: ViewMode;
  setView: (view: ViewMode) => void;
  onBack: () => void;
  onCopy: () => void;
  onReset: () => void;
}

const FormToolbar: React.FC<FormToolbarProps> = ({
  view,
  setView,
  onBack,
  onCopy,
  onReset,
}) => {
  return (
    <div className="form-toolbar">
      {/* Top row: View toggles and Recall */}
      <div className="toolbar-top-row">
        <div className="view-toggle-row">
          {["zoomed", "mid", "full"].map((mode) => (
            <button
              key={mode}
              className={`view-toggle-btn ${view === mode ? "active" : ""}`}
              onClick={() => setView(mode as ViewMode)}
            >
              {mode.charAt(0).toUpperCase() + mode.slice(1)}
            </button>
          ))}
        </div>

        <button
          className="recall-btn"
          onClick={() => console.log("Recall clicked!")}
        >
          🔁 Recall
        </button>
      </div>

      {/* Bottom row: Back and Continue */}
      <div className="toolbar-bottom-row">
        <div className="back-text" onClick={onBack}>
          ← Back
        </div>
        <button className="continue-btn">Continue</button>
      </div>
    </div>
  );
};

export default FormToolbar;

import React from "react";
import "./flraselectview.css";

interface Props {
  onSelect: (mode: "zoomed" | "mid" | "full") => void;
}

const FlraSelectView: React.FC<Props> = ({ onSelect }) => {
  return (
    <div className="view-select-page">
      <h2>Select FLRA View Mode</h2>
      <p>Please choose how you'd like to fill out your FLRA:</p>

      <div className="view-buttons">
        <button onClick={() => onSelect("zoomed")}>🔍 Zoomed-In View</button>
        <button onClick={() => onSelect("mid")}>🧾 Mid View</button>
        <button onClick={() => onSelect("full")}>🖨️ Full-Page View</button>
      </div>
    </div>
  );
};
export default FlraSelectView;

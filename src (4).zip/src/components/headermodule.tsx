// src/components/headermodule.tsx
import React from "react";
import "../styles/headermodules.css"; // Adjust the path as necessary

interface HeaderModuleProps {
  title: string;
  formId: string;
  createdDate: string;
  currentModule: string;
  viewMode: "guided" | "quickfill" | "fullview";
}

const HeaderModule: React.FC<HeaderModuleProps> = ({
  title,
  formId,
  createdDate,
  currentModule,
  viewMode,
}) => {
  const modeLabel = {
    guided: "Guided Mode",
    quickfill: "Quick Fill Mode",
    fullview: "Full View",
  }[viewMode];

  return (
    <div className="header-module">
      <div className="header-top">
        <div className="header-logo">
          <img src="/logo192.png" alt="HrdHat Logo" />
        </div>
        <div className="header-textblock">
          <h2 className="form-title">{title}</h2>
          <div className="form-meta">
            <span className="form-id">Form #: {formId}</span>
            <span className="created-date">Created: {createdDate}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeaderModule;

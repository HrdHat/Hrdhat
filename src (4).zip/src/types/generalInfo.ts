export interface GeneralInfoData {
  projectName: string;
  taskLocation: string;
  supervisorName: string;
  supervisorContact: string;
  todaysDate: string;
  crewMembers: string;
  todaysTask: string;
  startTime: string;
  endTime: string;
}

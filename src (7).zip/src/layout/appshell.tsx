import React, { useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";

import Sidebar from "../components/sidebar";
import FloatingPanel from "../components/floatingpanel";
import ActiveFormsContent from "../components/activeformscontent";
import { FLRASessionManager } from "../utils/flrasessionmanager";
import { ViewMode } from "../types/viewmode";
import FlraFormPage from "../pages/flraformpage";

const AppShell: React.FC = () => {
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [activePanel, setActivePanel] = useState<
    null | "create" | "activeForms"
  >(null);
  const [viewMode, setViewMode] = useState<ViewMode | null>(null);
  const [activeDraftId, setActiveDraftId] = useState<string | null>(null);

  const navigate = useNavigate();

  const openPanel = (panel: "create" | "activeForms") => {
    setActivePanel(null);
    setTimeout(() => setActivePanel(panel), 100);
  };

  const handleCreateForm = () => {
    const newDraft = FLRASessionManager.createNewDraft("New FLRA Form");
    setActiveDraftId(newDraft.id);
    setViewMode("guided");
    setActivePanel(null);
    navigate("/flra?view=guided");
  };

  const handleResumeForm = (id: string) => {
    setActiveDraftId(id);
    setViewMode("guided");
    setActivePanel(null);
    navigate("/flra?view=guided");
  };

  const handleClosePanel = () => {
    setActivePanel(null);
  };

  return (
    <div className="layout-wrapper">
      {/* Keep Sidebar outside the flow but visually aligned */}
      <Sidebar
        visible={sidebarVisible}
        onCreate={() => openPanel("create")}
        onHome={() => navigate("/")}
        onOpenActiveForms={() => openPanel("activeForms")}
      />

      {/* Floating Panel aligned next to the fixed sidebar */}
      <div className="content-region">
        <FloatingPanel
          title={activePanel === "create" ? "Create Form" : "Active FLRA Forms"}
          visible={activePanel !== null}
          onClose={handleClosePanel}
        >
          {activePanel === "create" && (
            <FlraFormPage
              draftId={activeDraftId ?? undefined}
              viewMode={viewMode ?? "guided"}
            />
          )}
          {activePanel === "activeForms" && (
            <ActiveFormsContent
              onClose={handleClosePanel}
              onResume={handleResumeForm}
            />
          )}
        </FloatingPanel>

        <main className="app-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AppShell;

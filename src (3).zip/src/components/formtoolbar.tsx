import React from "react";
import "../styles/components.css";
import "../styles/pagetoolbar.css";

type ViewMode = "zoomed" | "mid" | "full";

interface FormToolbarProps {
  view: ViewMode;
  setView: (view: ViewMode) => void;
  onBack: () => void;
  onCopy: () => void;
  onReset: () => void; // ✅ This is coming from the parent!
}

const FormToolbar: React.FC<FormToolbarProps> = ({
  view,
  setView,
  onBack,
  onCopy,
  onReset,
}) => {
  return (
    <div className="form-toolbar">
      <div className="toolbar-top-row">
        <div className="view-toggle-row">
          {["zoomed", "mid", "full"].map((mode) => (
            <button
              key={mode}
              className={`view-toggle-btn ${view === mode ? "active" : ""}`}
              onClick={() => setView(mode as ViewMode)}
            >
              {mode.charAt(0).toUpperCase() + mode.slice(1)}
            </button>
          ))}
        </div>

        <button
          className="recall-btn"
          onClick={() => console.log("Recall clicked!")}
        >
          🔁 Recall
        </button>
      </div>

      <div className="action-row">
        <div className="toolbar-left" onClick={onBack}>
          ← Back
        </div>

        <div className="toolbar-right">
          <button className="copy-btn" onClick={onCopy}>
            Copy from Yesterday
          </button>
          <button className="reset-btn" onClick={onReset}>
            Reset
          </button>
          <button className="continue-btn">Continue</button>
        </div>
      </div>
    </div>
  );
};

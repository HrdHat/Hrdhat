import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "../components/sidebar";
import FloatingPanel from "../components/floatingpanel";

const AppShell: React.FC = () => {
  const [activePanel, setActivePanel] = useState<
    null | "create" | "activeForms"
  >(null);

  const openPanel = (panel: "create" | "activeForms") => {
    setActivePanel(null);
    setTimeout(() => setActivePanel(panel), 100);
  };

  const closePanel = () => setActivePanel(null);

  return (
    <div className="layout-wrapper">
      <Sidebar
        visible={true}
        onCreate={() => openPanel("create")}
        onHome={closePanel}
        onOpenActiveForms={() => openPanel("activeForms")}
      />

      <FloatingPanel
        title={activePanel === "create" ? "Create Form" : "Active Forms"}
        visible={activePanel !== null}
        onClose={closePanel}
      >
        {activePanel === "create" && <div>Drawer content for Create Form</div>}
        {activePanel === "activeForms" && (
          <div>Drawer content for Active Forms</div>
        )}
      </FloatingPanel>

      <main className="app-content">
        <Outlet />
      </main>
    </div>
  );
};

export default AppShell;

import React from "react";
import "../styles/layout.css"; // 👈 contains your grid background styling

const HomePage = () => {
  return <div className="homepage" />; // 👈 empty, but renders background
};

export default HomePage;

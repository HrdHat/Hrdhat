import React from "react";
import FlraSelectView from "../components/flraselectview";

const HomePage = () => {
  return (
    <div className="homepage">
      <FlraSelectView />
    </div>
  );
};

export default HomePage;

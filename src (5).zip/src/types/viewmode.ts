export type ViewMode = "guided" | "quickfill" | "printview";

import React, { useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";

import Sidebar from "../components/sidebar";
import FloatingPanel from "../components/floatingpanel";
import ActiveFormsContent from "../components/activeformscontent";
import { FLRASessionManager } from "../utils/flrasessionmanager";
import { ViewMode } from "../types/viewmode";

const AppShell: React.FC = () => {
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [activePanel, setActivePanel] = useState<null | "activeForms">(null);
  const [viewMode, setViewMode] = useState<ViewMode | null>(null);
  const [activeDraftId, setActiveDraftId] = useState<string | null>(null);

  const navigate = useNavigate();

  const handleCreateForm = () => {
    const newDraft = FLRASessionManager.createNewDraft("New FLRA Form");
    setActiveDraftId(newDraft.id);
    setViewMode("guided");
    navigate("/flra?view=guided");
  };

  const handleOpenActiveForms = () => {
    setActivePanel("activeForms");
  };

  const handleClosePanel = () => {
    setActivePanel(null);
  };

  const handleResumeForm = (id: string) => {
    setActiveDraftId(id);
    setViewMode("guided"); // or pull stored mode from draft later
    handleClosePanel();
    navigate("/flra?view=guided");
  };

  return (
    <div className="layout-wrapper">
      <Sidebar
        visible={sidebarVisible}
        onCreate={handleCreateForm}
        onHome={() => navigate("/")}
        onOpenActiveForms={handleOpenActiveForms}
      />

      <FloatingPanel
        title="Active FLRA Forms"
        visible={activePanel === "activeForms"}
        onClose={handleClosePanel}
      >
        <ActiveFormsContent
          onClose={handleClosePanel}
          onResume={handleResumeForm}
        />
      </FloatingPanel>

      <main className="app-content">
        <Outlet />
      </main>
    </div>
  );
};

export default AppShell;
